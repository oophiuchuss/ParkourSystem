// Fill out your copyright notice in the Description page of Project Settings.


#include "ParkourABPInterface.h"

// Add default functionality here for any IParkourABPInterface functions that are not pure virtual.
